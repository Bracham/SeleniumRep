package utilities;

public class Constants {
    public static final String NEXT_HOME_PAGE_URL = "https://www.next.co.il/en";


    public static final String CONFIG_FILE_PATH = "C:\\Users\\bracham\\SeleniumProjectNextSite\\src\\test\\java\\utilities\\config.xml";

    // Page Titles
    public static final String SIGN_IN_PAGE_TITLE = "Sign In | My Account | Next Directory Online";
    public static final String HOMEPAGE_TITLE = "Next Official Site: Online Fashion, Kids Clothes & Homeware";
    public static final String MY_ACCOUNT_PAGE_TITLE = "My Orders | My Account |  Next Directory Online";
    public static final String HOME_CATEGORY_PAGE_TITLE = "Furniture & Homeware | Next Home & Garden | Next UK";
    public static final String SUB_CATEGORY_LIVING_ROOM_PAGE_TITLE = "Living Room | All Living Room Accessories | Next Israel";
    public static final String LIGHTING_PAGE_TITLE = "Lighting | Indoor & Outdoor Lights | Next Israel";
    public static final String BABY_PAGE_TITLE = "Baby Clothes | Baby Gifts, Onesies & Essentials | Next UK";
    public static final String NEXT_HOME_HEBREW_TITLE = "האתר הרשמי של Next: אופנה, בגדי ילדים ועיצוב הבית אונליין";
    public static final String PRODUCT_PAGE_TITLE = "Buy Cotton Rich Stretch Jeans (3-17yrs) from Next Israel";
    public static final String SHOPPING_BAG_PAGE_TITLE = "Next Israel";
    public static final String PAYMENT_PAGE_TITLE = "Sign In | My Account | Next Directory Online";

    // Methods for waiting
    public static final void wait1() throws InterruptedException {
        Thread.sleep(2000);
    }

    public static final void wait2() throws InterruptedException {
        Thread.sleep(3000);
    }
}

