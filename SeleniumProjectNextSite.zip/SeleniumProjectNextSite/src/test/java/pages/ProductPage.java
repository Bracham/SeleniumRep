package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import utilities.Constants;

// This page contains the details and functions for the product (pants)
public class ProductPage {
    // Set up driver
    private static WebDriver driver;

    // Locators on webPage
    private By searchLocator = By.id("header-big-screen-search-box");
    private By colorDropDownLocator = By.linkText("Indigo");
    private By naturalPantsLocator = By.linkText("Ecru Natural");
    private By sizeDropDownLocator = By.linkText("Choose Size");
    private By size_16Locator = By.linkText("16 Years (UK ) (EU 176cm) - ₪ 67");
    private By addToBagBtnLocator = By.xpath("/html/body/section[1]/section[1]/div[1]/div[2]/div[2]/div/section[2]/article/section/div[4]/div[6]/div[4]/div/a[1]");
    private By bagIconLocator = By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[2]/div[4]/div[2]/a/div");
    private By viewEditBagLocator = By.linkText("VIEW/EDIT BAG");
    private By quantityDropDownLocator = By.xpath("//*[@id=\"dk_container_Qty_1\"]/a");
    private By addQuantityLocator = By.xpath("//*[@id=\"dk_container_Qty_1\"]/div/ul/li[2]/a");
    private By checkoutBtnLocator = By.linkText("CHECKOUT");
    private By productName= By.xpath("/html/body/section[1]/section[1]/div[1]/section/div[2]/div[4]/div[2]/table/tbody/tr[1]/td[2]/div/h3");

    // Constructor
    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    // A method to search products by name or model number
    public void search(String item) throws InterruptedException {
        driver.findElement(searchLocator).click();
        driver.findElement(searchLocator).sendKeys(item);
        driver.findElement(searchLocator).sendKeys(Keys.ENTER);
        Constants.wait1();
    }

    // A method for choosing the color of the pants
    public void chooseColorOfPants() {
        driver.findElement(colorDropDownLocator).click();
        driver.findElement(naturalPantsLocator).click();
    }

    // A method for choosing the size of the pants
    public void chooseSizeOfPants() {
        driver.findElement(sizeDropDownLocator).click();
        driver.findElement(size_16Locator).click();
    }

    // A method to click on add to bag btn
    public void clickAddToBag() throws InterruptedException {
        driver.findElement(addToBagBtnLocator).click();
        Constants.wait1();
    }

    // A method to click on bag icon
    public void clickMyBag() {
        driver.findElement(bagIconLocator).click();
    }

    // A method to click on view/edit btn
    public void clickViewOrEditBag() {
        driver.findElement(viewEditBagLocator).click();
//        Actions actions = new Actions(driver);
//        WebElement view = driver.findElement(viewEditBagLocator);
//        actions.doubleClick(view).perform();
    }

    // A method to add another item from the same type
    public void addAnotherItemFromSameType() throws InterruptedException {
        driver.findElement(quantityDropDownLocator).click();
        Constants.wait1();
        driver.findElement(addQuantityLocator).click();
    }

    // A method to click on check out btn
    public void goToCheckOut() {
        driver.findElement(checkoutBtnLocator).click();
    }

    // Functions that receive the text from the field
    public String getSelectedColour() {
        return driver.findElement(colorDropDownLocator).getText();
    }
    public String getSelectedSize() {
        return driver.findElement(sizeDropDownLocator).getText();
    }
    public String getSelectedAmount() {
        return driver.findElement(quantityDropDownLocator).getText();
    }
    public String getSelectedProductName (){
        return driver.findElement(productName).getText();
    }


}


