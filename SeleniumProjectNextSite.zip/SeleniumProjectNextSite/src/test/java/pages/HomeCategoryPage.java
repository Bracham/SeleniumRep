package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.xml.sax.SAXException;
import utilities.Utilities;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

public class HomeCategoryPage {
    // Set up driver
    private static WebDriver driver;
    Utilities utilities= new Utilities(driver);

    // Locators on page
    private By sideLinkLivingRoomLocator = By.xpath("//*[@id=\"left-sidebar-links3-589949kn0vtulvh7e4s66uhm\"]");
    private By lightingCategoryLocator = By.linkText("Lighting");
    private By bannerBabyLocator =  By.xpath("//*[@id=\"meganav-link-2\"]/div");

    // Constructor
    public HomeCategoryPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods

    // A method to click on lighting category-center link
    public void clickLighting() {
        driver.findElement(lightingCategoryLocator).click();
    }

    // A method to click on living room side-link
    public void doubleClickLivingRoom() {
        Actions actions = new Actions(driver);
        WebElement livingRoom = driver.findElement(sideLinkLivingRoomLocator);
        actions.doubleClick(livingRoom).perform();
    }
    // A method to click on baby category in banner
    public void doubleClickBabyInBanner (){
        Actions actions = new  Actions(driver);
        WebElement babyBanner =driver.findElement(bannerBabyLocator);
        actions.doubleClick(babyBanner).build().perform();
    }

    // A method to return to home category page
    public void returnToHomeCategoryPage() throws ParserConfigurationException, IOException, SAXException {
        driver.navigate().to(utilities.getDataItem("URL",1));
    }

}
