package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.xml.sax.SAXException;
import utilities.Constants;
import utilities.Utilities;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

public class NextPage {
    Utilities utilities = new Utilities(driver);

    // Set up driver
    private static WebDriver driver;

    // Locators on page
    private By myAccountLocator = By.linkText("My Account");
    private By countryAndLanguageLocator = By.className("header-q6ti7y");
    private By hebrewBtnLocator = By.className("header-6pbnht");
    private By shopNowLocator = By.xpath("//*[@id=\"header-country-selector-wrapper\"]/div/div[3]/div/div[5]/button");
    private By homeCategoryLocator = By.xpath("//*[@id=\"meganav-link-7\"]/div");


    // Constructor
    public NextPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods
    //Click on my account button

    public void clickMyAccountBtn() {
        driver.findElement(myAccountLocator).click();
    }

    // Double-click on home button
    public void doubleClickHomeBtn() {
        Actions actions = new Actions(driver);
        WebElement homeCategory = driver.findElement(homeCategoryLocator);
        actions.doubleClick(homeCategory).perform();
    }

    // Click on home category
    public void ClickHomeBtn() {
        driver.findElement(homeCategoryLocator).click();
    }

    //A function that changes the website language to Hebrew
    public void changeLanguageToHebrew() throws InterruptedException {
        driver.findElement(countryAndLanguageLocator).click();
        Constants.wait1();
        driver.findElement(hebrewBtnLocator).click();
        driver.findElement(shopNowLocator).click();
    }

    // A method to return to home page
    public void returnToHomePage() throws ParserConfigurationException, IOException, SAXException {
        driver.navigate().to(utilities.getData("URL"));
    }
}
