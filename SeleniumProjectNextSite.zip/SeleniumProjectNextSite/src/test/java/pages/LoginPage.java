package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    // Set up driver
    private static WebDriver driver;

    //Locators on page
    private By emailAddressLocator = By.id("EmailOrAccountNumber");
    private By passwordLocator = By.id("Password");
    private By loginLocator = By.id("SignInNow");


    // Constructor
    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }


    // Methods

    // A method for entering an email address
    public void enterEmailAddress(String emailAddress) {
        driver.findElement(emailAddressLocator).sendKeys(emailAddress);
    }

    // A method for entering a password
    public void enterPassword(String password) {
        driver.findElement(passwordLocator).sendKeys(password);
    }

    // A method to press the login key
    public void clickSignInBtn() {
        driver.findElement(loginLocator).click();
    }


}
