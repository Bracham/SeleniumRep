package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utilities.Utilities;

public class PaymentPage {
    // Set up driver
    private static WebDriver driver;
    Utilities utilities= new Utilities(driver);



    // Locators on page
    private By creditDebitCardLocator = By.xpath("//*[@id=\"card_option\"]/div/img[3]");
    private By cardNumberLocator = By.id("cardNumber");
    private By expiryDateMonthLocator = By.id("expiryMonth");
    private By expiryDateYearLocator = By.id("expiryYear");
    private By cardHoldersNameLocator = By.id("cardholderName");
    private By securityCodeLocator = By.id("securityCode");
    private By payNowLocator = By.xpath("//*[@id=\"submitButton\"]");
    private By errorMessageLocator= By.id("cardNumber-hint");


    // Constructor
    public PaymentPage(WebDriver driver) {
        this.driver = driver;
    }
    public void choosePaymentType (){
        driver.findElement(creditDebitCardLocator).click();
    }
    // Methods
    // A function designed to receive the credit card information and enter it in the appropriate fields
    public void cardDetails(String cardNumber,String exMonth,String exYear,String securityCode ){
        driver.findElement(creditDebitCardLocator).click();
        driver.findElement(cardNumberLocator).sendKeys(cardNumber);
        driver.findElement(expiryDateMonthLocator).sendKeys(exMonth);
        driver.findElement(expiryDateYearLocator).sendKeys(exYear);
        driver.findElement(securityCodeLocator).sendKeys(securityCode);
        driver.findElement(payNowLocator).click();
    }
    // Function that receive the text from the field
    public String getCardErrorMessage(){
        return driver.findElement(errorMessageLocator).getText();
    }




}
