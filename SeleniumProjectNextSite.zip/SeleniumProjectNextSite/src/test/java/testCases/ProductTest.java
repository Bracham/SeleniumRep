package testCases;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.xml.sax.SAXException;
import pages.NextPage;
import pages.ProductPage;
import utilities.Constants;
import utilities.Utilities;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;


public class ProductTest {
    private static WebDriver driver;
    public static ExtentSparkReporter extentSparkReporter = new ExtentSparkReporter("index.html");
    public static ExtentReports extentReports = new ExtentReports();
    ProductPage productPage = new ProductPage(driver);

    NextPage nextPage = new NextPage(driver);
    Utilities utilities = new Utilities(driver);

    //  This page is a sanity test for choosing a product, changing to a different color and size and adding to shopping bag
    @BeforeClass
    public static void beforeClass() {
        extentReports.attachReporter(extentSparkReporter);
        extentSparkReporter.config().setTheme(Theme.DARK);
        extentSparkReporter.config().setReportName("Report");
        System.out.println("*******  beforeClass  *******");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("-incognito");
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(Constants.NEXT_HOME_PAGE_URL);
    }

    //Checking that the search returns appropriate results
    @Test
    public void searchItem() throws ParserConfigurationException, IOException, SAXException, InterruptedException {
        ExtentTest searchTest = extentReports.createTest("Search Test");
        searchTest.log(Status.INFO, "Search Test started");
        String currentTime = String.valueOf(System.currentTimeMillis());
        try {
            productPage.search(utilities.getData("PRODUCT"));
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            Assert.assertEquals(Constants.PRODUCT_PAGE_TITLE, driver.getTitle());
            searchTest.pass("search returned the appropriate result");
        } catch (AssertionError assertionError) {
            searchTest.fail("search did not return the appropriate result", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());
        }
    }

    //Choose color test and verification
    @Test
    public void colorTest() throws ParserConfigurationException, IOException, SAXException {
        String currentTime = String.valueOf(System.currentTimeMillis());
        ExtentTest changeColor = extentReports.createTest("Change color of product");
        changeColor.log(Status.INFO, "change color of product test started");
        driver.navigate().to(utilities.getDataItem("URL", 2));
        String expectedColour = "Ecru Natural";
        try {
            productPage.chooseColorOfPants();
            Assert.assertEquals(expectedColour, productPage.getSelectedColour());
            changeColor.pass("test passed, the color indigo was selected");
        } catch (Exception e) {
            e.printStackTrace();
            changeColor.fail("test failed, there was a problem selecting the color you chose", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());
        }
    }

    //Choose size test and verification
    @Test
    public void SizeTest() throws ParserConfigurationException, IOException, SAXException {
        String currentTime = String.valueOf(System.currentTimeMillis());
        ExtentTest changeSize = extentReports.createTest("Change size of product");
        changeSize.log(Status.INFO, "change size of product test started");
        driver.navigate().to(utilities.getDataItem("URL", 2));
        String expectedSize = "16 Years (UK ) (EU 116cm) - ₪ 46";
        try {
            productPage.chooseSizeOfPants();
            Assert.assertEquals(expectedSize, productPage.getSelectedSize());
            changeSize.pass("test passed, size 16 was selected");
        } catch (Exception e) {
            changeSize.fail("test failed, there was a problem selecting the size you chose", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());
        }
    }

    //Test to check the product and the quantity selected
    @Test
    public void test() throws ParserConfigurationException, IOException, SAXException, InterruptedException {
        String currentTime = String.valueOf(System.currentTimeMillis());
        ExtentTest productTest = extentReports.createTest("Product and quantity test");
        productTest.log(Status.INFO, "Product and quantity test started");
        driver.navigate().to(utilities.getDataItem("URL", 2));
        productPage.chooseColorOfPants();
        productTest.log(Status.INFO, "Choosing the color of the pants");
        productPage.chooseSizeOfPants();
        productTest.log(Status.INFO, "Choosing the size of the pants");
        productPage.clickAddToBag();
        productPage.clickMyBag();
        Constants.wait2();
        productTest.log(Status.INFO, "Product added to bag");
//        productPage.clickViewOrEditBag();
        driver.navigate().to("https://www.next.co.il/en/shoppingbag");
        String expectedProduct = "Ecru Natural Cotton Rich Stretch Jeans (3-17yrs)";
        String actualProduct = productPage.getSelectedProductName();
        productPage.addAnotherItemFromSameType();
        if (actualProduct.equalsIgnoreCase(expectedProduct))
            productTest.log(Status.PASS, "Test passed, the expected product was successfully added to bag");
        else
            productTest.log(Status.FAIL, "Test failed, there was a problem selecting the product you chose", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());

        String expectedQuantity = "2";
        String actualQuantity = productPage.getSelectedAmount();
        productPage.addAnotherItemFromSameType();
        if (actualQuantity.equalsIgnoreCase(expectedQuantity))
            productTest.log(Status.PASS, "Test passed, the expected amount was successfully added to bag");
        else
            productTest.log(Status.FAIL, "Test failed, there was a problem selecting the amount you chose", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());

        try {
            productPage.goToCheckOut();
            Assert.assertEquals(Constants.PAYMENT_PAGE_TITLE, driver.getTitle());
            productTest.log(Status.PASS, "Test passed, payment page was reached successfully");
            productTest.log(Status.INFO, "End of Product and quantity test");
        } catch (AssertionError assertionError) {
            productTest.log(Status.FAIL, "Test failed, there was a problem reaching the payment page", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());
        }
    }

    @AfterClass
    public static void afterClass() throws InterruptedException {
        extentReports.flush();
        Thread.sleep(5000);
        System.out.println("*********  afterClass  *******");
        driver.quit();
    }
}
