package testCases;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.xml.sax.SAXException;
import pages.LoginPage;
import pages.NextPage;
import pages.PaymentPage;
import pages.ProductPage;
import utilities.Constants;
import utilities.Utilities;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class PaymentTest {
    private static WebDriver driver;
    public static ExtentSparkReporter extentSparkReporter = new ExtentSparkReporter("index.html");
    public static ExtentReports extentReports = new ExtentReports();

    Utilities utilities = new Utilities(driver);
    NextPage nextPage = new NextPage(driver);
    LoginPage loginPage = new LoginPage(driver);
    ProductPage productPage = new ProductPage(driver);
    PaymentPage paymentPage = new PaymentPage(driver);

    //  This page is a sanity test for Paying for a selected product
    @BeforeClass
    public static void beforeClass() {
        extentReports.attachReporter(extentSparkReporter);
        extentSparkReporter.config().setTheme(Theme.DARK);
        extentSparkReporter.config().setReportName("Report");
        System.out.println("*******  beforeClass  *******");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("-incognito");
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(Constants.NEXT_HOME_PAGE_URL);
    }


    // The test will fail on the login due to site limitation and be reported as failure
    // The test will check the payment process, and that an error message is received for an invalid credit card number
    @Test
    public void paymentTest() throws ParserConfigurationException, IOException, SAXException, InterruptedException {
        String currentTime = String.valueOf(System.currentTimeMillis());
        ExtentTest paymentTest = extentReports.createTest("payment Test");
        paymentTest.log(Status.INFO, "payment Test started");
        driver.navigate().to(utilities.getDataItem("URL", 2));
        Constants.wait1();
        productPage.chooseColorOfPants();
        productPage.chooseSizeOfPants();
        productPage.clickAddToBag();
        productPage.goToCheckOut();
        Constants.wait2();
        loginPage.enterEmailAddress(utilities.getData("EMAIL"));
        loginPage.enterPassword(utilities.getData("PASSWORD"));
        loginPage.clickSignInBtn();
        Constants.wait2();
        paymentPage.choosePaymentType();
        paymentPage.cardDetails(utilities.getData("CARD_NUMBER"),utilities.getData("EX_MONTH"),utilities.getData("EX_YEAR"),utilities.getData("SECURITY_CODE"));
        String expectedCardErrorMessage = "Enter a valid card number";
        try {
            Assert.assertEquals(expectedCardErrorMessage, paymentPage.getCardErrorMessage());
            paymentTest.log(Status.PASS, "Test passed -invalid card message displayed");
        } catch (AssertionError assertionError) {
            paymentTest.log(Status.FAIL, "Test failed, error message is not displayed", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());
        }
    }

    @AfterClass
    public static void afterClass() throws InterruptedException {
        extentReports.flush();
        Thread.sleep(2000);
        System.out.println("*********  afterClass  *******");
        driver.quit();
    }
}
