package testCases;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.xml.sax.SAXException;
import pages.HomeCategoryPage;
import pages.NextPage;
import utilities.Constants;
import utilities.Utilities;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;


public class HomePageTest {
    private static WebDriver driver;
    public static ExtentSparkReporter extentSparkReporter = new ExtentSparkReporter("index.html");
    public static ExtentReports extentReports = new ExtentReports();

    HomeCategoryPage homeCategoryPage = new HomeCategoryPage(driver);
    NextPage nextPage = new NextPage(driver);
    Utilities utilities = new Utilities(driver);

    // This page will test clicking on different links in home category and verifying that links reach the right Webpages
    @BeforeClass
    public static void beforeClass() {
        extentReports.attachReporter(extentSparkReporter);
        extentSparkReporter.config().setTheme(Theme.DARK);
        extentSparkReporter.config().setReportName("Report");
        System.out.println("*******  beforeClass  *******");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("-incognito");
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(Constants.NEXT_HOME_PAGE_URL);
    }

    //Click and Verify link of home category
    @Test
    public void homeCategoryTest() throws IOException {
        ExtentTest homeCategoryTest = extentReports.createTest("Home Category Test");
        homeCategoryTest.log(Status.INFO, "Home Category Test started");
        String currentTime = String.valueOf(System.currentTimeMillis());
        try {
            nextPage.doubleClickHomeBtn();
            Assert.assertEquals(Constants.HOME_CATEGORY_PAGE_TITLE, driver.getTitle());
            homeCategoryTest.pass("You reached the home page category");
        } catch (AssertionError assertionError) {
            homeCategoryTest.fail("the home page category was not reached", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());
        }
    }

    //Click on one of the links on the left side and verification
    @Test
    public void leftSideLinkTest() throws IOException {
        ExtentTest leftSideLinkTest = extentReports.createTest("Left Side Link Test");
        leftSideLinkTest.log(Status.INFO, "left Side Link Test started");
        String currentTime = String.valueOf(System.currentTimeMillis());
        nextPage.doubleClickHomeBtn();
        try {
            homeCategoryPage.doubleClickLivingRoom();
            Assert.assertEquals(Constants.SUB_CATEGORY_LIVING_ROOM_PAGE_TITLE, driver.getTitle());
            leftSideLinkTest.pass("living room subcategory was reached through the link on the left side");
        } catch (AssertionError assertionError) {
            leftSideLinkTest.fail("living room subcategory was not reached through the link on the left side", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic4" + currentTime)).build());
        }
        //Return to homepage Home Category and verification
        try {
            homeCategoryPage.returnToHomeCategoryPage();
            leftSideLinkTest.log(Status.PASS, "Returning to home page category has been successfully completed");
        } catch (AssertionError | ParserConfigurationException | SAXException assertionError) {
            leftSideLinkTest.log(Status.FAIL, "Failed to return to home page category", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic4" + currentTime)).build());
        }
    }

    //Click on a category from the center of page and verification
    @Test
    public void centerLinkTest() throws IOException, ParserConfigurationException, SAXException {
        ExtentTest centerLinkTest = extentReports.createTest("Center Link Test");
        centerLinkTest.log(Status.INFO, "left Side Link Test started");
        String currentTime = String.valueOf(System.currentTimeMillis());
        try {
            homeCategoryPage.clickLighting();
            Assert.assertEquals(Constants.LIGHTING_PAGE_TITLE, driver.getTitle());
            centerLinkTest.pass("lighting page was reached through the link in the center");
        } catch (AssertionError assertionError) {
            centerLinkTest.fail("lighting page was not reached through the link in the center", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());
        }
        homeCategoryPage.returnToHomeCategoryPage();
    }

    //Testing the top banner category links and verification
    @Test
    public void bannerMainLink() throws ParserConfigurationException, IOException, SAXException {
        String currentTime = String.valueOf(System.currentTimeMillis());
        ExtentTest bannerLinkTest = extentReports.createTest("Banner Link Test");
        bannerLinkTest.log(Status.INFO, "Banner Link Test started");
        try {
            homeCategoryPage.doubleClickBabyInBanner();
            Assert.assertEquals(Constants.BABY_PAGE_TITLE, driver.getTitle());
            bannerLinkTest.pass("Baby page was reached through the link in the banner");
        } catch (AssertionError assertionError) {
            bannerLinkTest.fail("Baby page was not reached through the link in the banner", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());
        }
        homeCategoryPage.returnToHomeCategoryPage();
    }

    // This test will check changing the language of site from English to Hebrew
    @Test
    public void ChangeLanguage() throws InterruptedException, IOException, ParserConfigurationException, SAXException {
        String currentTime = String.valueOf(System.currentTimeMillis());
        ExtentTest changeLanguage = extentReports.createTest("Change Language To Hebrew");
        changeLanguage.log(Status.INFO, "change Language To Hebrew test started");
        try {
            nextPage.changeLanguageToHebrew();
            Assert.assertEquals(Constants.NEXT_HOME_HEBREW_TITLE, driver.getTitle());
            changeLanguage.log(Status.PASS, "Language changed successfully from English to Hebrew");
        } catch (AssertionError assertionError) {
            changeLanguage.fail("Language did not change from English to Hebrew", MediaEntityBuilder.createScreenCaptureFromPath(utilities.takeScreenShot("index.html" + "pic3" + currentTime)).build());
        }
        homeCategoryPage.returnToHomeCategoryPage();
    }

    @AfterClass
    public static void afterClass() throws InterruptedException {
        extentReports.flush();
        Thread.sleep(5000);
        System.out.println("*********  afterClass  *******");
        driver.quit();
    }

}
